/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_253(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_280(unsigned x)
{
    return x + 2428996040U;
}

void setval_461(unsigned *p)
{
    *p = 3281016950U;
}

unsigned getval_159()
{
    return 2417511861U;
}

unsigned getval_121()
{
    return 3251079496U;
}

void setval_391(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_227()
{
    return 4291268696U;
}

unsigned getval_399()
{
    return 1481502946U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_423(unsigned *p)
{
    *p = 2429454615U;
}

unsigned getval_338()
{
    return 3269495112U;
}

void setval_256(unsigned *p)
{
    *p = 3526935177U;
}

unsigned getval_212()
{
    return 3268007048U;
}

unsigned addval_241(unsigned x)
{
    return x + 2425409033U;
}

void setval_320(unsigned *p)
{
    *p = 2428668063U;
}

unsigned getval_317()
{
    return 3223372441U;
}

unsigned getval_329()
{
    return 3353381192U;
}

unsigned addval_419(unsigned x)
{
    return x + 3032728073U;
}

void setval_249(unsigned *p)
{
    *p = 3285289070U;
}

void setval_383(unsigned *p)
{
    *p = 3281179017U;
}

unsigned addval_156(unsigned x)
{
    return x + 3767101546U;
}

unsigned getval_218()
{
    return 3221803401U;
}

void setval_333(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_293()
{
    return 2425672073U;
}

void setval_211(unsigned *p)
{
    *p = 3229929099U;
}

unsigned getval_250()
{
    return 3281047179U;
}

void setval_300(unsigned *p)
{
    *p = 2429455709U;
}

unsigned getval_421()
{
    return 2430634312U;
}

unsigned getval_313()
{
    return 2497743176U;
}

unsigned getval_235()
{
    return 2429655532U;
}

unsigned addval_191(unsigned x)
{
    return x + 3221802633U;
}

void setval_232(unsigned *p)
{
    *p = 3523789449U;
}

void setval_182(unsigned *p)
{
    *p = 3676361097U;
}

unsigned getval_465()
{
    return 3281047179U;
}

unsigned getval_349()
{
    return 2630078861U;
}

void setval_111(unsigned *p)
{
    *p = 3380920968U;
}

unsigned addval_275(unsigned x)
{
    return x + 2430634344U;
}

void setval_481(unsigned *p)
{
    *p = 3286272328U;
}

void setval_208(unsigned *p)
{
    *p = 3232023177U;
}

unsigned addval_310(unsigned x)
{
    return x + 3531132553U;
}

unsigned addval_217(unsigned x)
{
    return x + 3674788237U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
